import warnings
warnings.filterwarnings('ignore')
from ultralytics import YOLO

# onnx onnxsim onnxruntime onnxruntime-gpu

if __name__ == '__main__':
    # Load a model
    # model = YOLO('yolov8n.pt')  # load an official model
    model = YOLO('E:\\ultralytics-20240222\\runs\\train\\exp-yolov8n-GDFPN-C2f-DWR-DRB-AIFI\\weights\\best.pt')  # load a custom trained
    model.export(format='onnx', simplify=True, opset=13)