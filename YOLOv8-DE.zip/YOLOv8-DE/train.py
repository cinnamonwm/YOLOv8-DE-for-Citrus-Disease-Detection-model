import warnings
warnings.filterwarnings('ignore')
from ultralytics import YOLO

if __name__ == '__main__':
    model = YOLO('E:\\ultralytics-my200708\\ultralytics\\cfg\\models\\v8\\yolov8-DBBNCSPELAN.yaml')
    # model.load('yolov8n.pt') # loading pretrain weights
    model.train(data='E:\\ultralytics-my200708\\dataset1\\data.yaml',
                cache=False,
                imgsz=640,
                epochs=200,
                batch=8,
                close_mosaic=0,
                workers=4,
                device='0',
                optimizer='SGD', # using SGD
                # resume='', # last.pt path
                # amp=False, # close amp
                # fraction=0.2,
                project='runs/train',
                name='yolov8n-1',
                )