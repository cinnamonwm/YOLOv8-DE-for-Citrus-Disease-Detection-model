import warnings

#测试图片/视频并可视化目标数量

warnings.filterwarnings('ignore')
import cv2, os, shutil
import numpy as np
from ultralytics import YOLO


def get_video_cfg(path):
    video = cv2.VideoCapture(path)
    size = (int(video.get(cv2.CAP_PROP_FRAME_WIDTH)), int(video.get(cv2.CAP_PROP_FRAME_HEIGHT)))
    fps = int(video.get(cv2.CAP_PROP_FPS))
    return cv2.VideoWriter_fourcc(*'XVID'), size, fps


def plot_and_counting(result):
    image_plot = result.plot()
    box_count = result.boxes.shape[0]  #取推理目标数量
    a_count = (result.boxes.cls.cpu().detach().numpy() == 0).sum()  # 取推理中病害a的数量names: ['a','c','h','m','n','p']
    c_count = (result.boxes.cls.cpu().detach().numpy() == 1).sum()  # 取推理中病害c的数量names: ['a','c','h','m','n','p']
    h_count = (result.boxes.cls.cpu().detach().numpy() == 2).sum()  # 取推理中病害h的数量names: ['a','c','h','m','n','p']
    m_count = (result.boxes.cls.cpu().detach().numpy() == 3).sum()  # 取推理中病害m的数量names: ['a','c','h','m','n','p']
    n_count = (result.boxes.cls.cpu().detach().numpy() == 4).sum()  # 取推理中病害n的数量names: ['a','c','h','m','n','p']
    p_count = (result.boxes.cls.cpu().detach().numpy() == 5).sum()  # 取推理中病害p的数量names: ['a','c','h','m','n','p']

    cv2.putText(image_plot, f'Object Counts:{box_count}', (10, 50), cv2.FONT_HERSHEY_SIMPLEX, 1.5, (0, 0, 255), 4) #显示推理目标数量,(10, 50)显示的位置，1.5字体大小。(0, 0, 255)字体颜色
    cv2.putText(image_plot, f'a Counts:{a_count}', (10, 150), cv2.FONT_HERSHEY_SIMPLEX, 1.5, (0, 0, 255), 4) #显示推理中病害a的数量
    cv2.putText(image_plot, f'c Counts:{c_count}', (10, 200), cv2.FONT_HERSHEY_SIMPLEX, 1.5, (0, 0, 255), 4)  # 显示推理中病害c的数量
    cv2.putText(image_plot, f'h Counts:{h_count}', (10, 250), cv2.FONT_HERSHEY_SIMPLEX, 1.5, (0, 0, 255), 4)  # 显示推理中病害h的数量
    cv2.putText(image_plot, f'm Counts:{m_count}', (10, 300), cv2.FONT_HERSHEY_SIMPLEX, 1.5, (0, 0, 255), 4)  # 显示推理中病害m的数量
    cv2.putText(image_plot, f'n Counts:{n_count}', (10, 350), cv2.FONT_HERSHEY_SIMPLEX, 1.5, (0, 0, 255), 4)  # 显示推理中病害n的数量
    cv2.putText(image_plot, f'p Counts:{p_count}', (10, 400), cv2.FONT_HERSHEY_SIMPLEX, 1.5, (0, 0, 255), 4)  # 显示推理中病害p的数量
    return image_plot


if __name__ == '__main__':
    output_dir = 'E:\\ultralytics-20240222\\runs\\result\\yolov8n\\count'
    if os.path.exists(output_dir):
        shutil.rmtree(output_dir)
    os.makedirs(output_dir, exist_ok=True)

    model = YOLO('E:\\ultralytics-20240222\\runs\\train\\exp-yolov8n\\weights\\best.pt')  # select your model.pt path模型选择

    # ----------------------for images or images-folder----------------------
    for result in model.predict(source='ultralytics/assets', #推理图片路径或文件夹
                                 stream=True,
                                 imgsz=640,
                                 save=False,
                                 # conf=0.2,
                                 ):
         image_plot = plot_and_counting(result)     #打断点看结果
         cv2.imwrite(f'{output_dir}/{os.path.basename(result.path)}', image_plot)

      # ----------------------for video-folder视频文件夹----------------------
      # video_base_path = 'E:\\ultralytics-20240222\\datasets\\video'
      # for video_path in os.listdir(video_base_path):
      #      fourcc, size, fps = get_video_cfg(f'{video_base_path}/{video_path}')
      #      video_output = cv2.VideoWriter(f'{output_dir}/{video_path}', fourcc, fps, size)
      #      for result in model.predict(source=f'{video_base_path}/{video_path}',
      #                    stream=True,
      #                    imgsz=640,
      #                    save=False,
      #                    # conf=0.2,
      #                    ):
      #          image_plot = plot_and_counting(result)
      #          video_output.write(image_plot)
      #      video_output.release()